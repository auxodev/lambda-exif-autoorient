var ExifImage = require('exif').ExifImage;


exports.handler = function(event, context) {
   console.log('Received event:');
   console.log(JSON.stringify(event, null, '  '));
   // Get the object from the event and show its content type
   var bucket = event.Records[0].s3.bucket.name;
   var key = event.Records[0].s3.object.key;
   s3.getObject({Bucket:bucket, Key:key},
      function(err,data) {
        if (err) {
           console.log('error getting object ' + key + ' from bucket ' + bucket +
               '. Make sure they exist and your bucket is in the same region as this function.');
           context.done('error','error getting file'+err);
        }
        else {
           console.log('CONTENT TYPE:',data.ContentType);
			console.log("data",JSON.stringify(data));
           context.done(null,'');
		 	new ExifImage({ image : 'https://s3.amazonaws.com/lambda-sourcebucket-auxo/HappyFace.jpg' }, function (error, exifData) {
	        if (error)
	            console.log('Error: '+error.message);
	        else{

				console.log("image " + exifData.image.Orientation);
	            console.log("exifData"); // Do something with your data!
	            console.log(exifData); // Do something with your data!
				// var type = {"image":{"Orientation":"n"}};
				// console.log("aa", aa.A.c(exifData, type));

				//
				// if(aa.B.c(exifData, {"image":{"Orientation":"n"}})){
				// 	return exifData.image.Orientation
				// }
				// else{
				// 	return 1;
				// }
			}
	    });
        }
      }
   );
};
