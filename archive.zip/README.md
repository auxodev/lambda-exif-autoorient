#README

##Process

`Can't find module index.js`. This error was due to compressing the whole folder instead of its contents.

`s3 undefined`: Wasn't importing the aws module.

####It seems I need to compress+upload+click the save/invoke button everytime I want to test something

Nice upgrade: zip the contents on save.
Most basic version:

##Using the aws cli:

If you have never used the aws cli you'll need to install it and run `aws config`.

Then to zip the contents of this folder run `zip -r archive.zip ./*`

Then to upload the code:

		aws lambda upload-function \
		   --region us-east-1 \
		   --function-name ViuAutoOrient  \
		   --function-zip ./archive.zip \
		   --role arn:aws:iam::446362648863:role/lambda_exec_role_viu_autoorient \
		   --mode event \
		   --handler index.handler \
		   --runtime nodejs \
		   --debug \
		   --timeout 60 \
		   --memory-size 1024
